import torch
import numpy as np
try:
    input = torch.rand([16, 4680306285591971493, 5], dtype=torch.float32)
    n = -15894627587359150439
    dim = -6468693411063459716
    norm = "ortho"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
