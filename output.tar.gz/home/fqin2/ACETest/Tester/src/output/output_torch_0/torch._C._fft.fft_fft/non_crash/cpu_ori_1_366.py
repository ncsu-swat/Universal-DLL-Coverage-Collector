import torch
import numpy as np
try:
    input = torch.rand([8, 11, 0, 0], dtype=torch.float32)
    n = 741
    dim = 4
    norm = "ortho"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
