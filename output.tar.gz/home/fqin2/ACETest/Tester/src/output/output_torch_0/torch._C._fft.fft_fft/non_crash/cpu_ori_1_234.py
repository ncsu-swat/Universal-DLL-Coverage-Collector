import torch
import numpy as np
try:
    input = torch.rand([6806494107220983259, 13], dtype=torch.float32)
    n = 11904026095040694294
    dim = -14905207491285517499
    norm = "backward"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
