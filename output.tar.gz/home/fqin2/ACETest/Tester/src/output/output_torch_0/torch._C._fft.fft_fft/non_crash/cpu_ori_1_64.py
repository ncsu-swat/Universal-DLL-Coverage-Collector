import torch
import numpy as np
try:
    input = torch.rand([3, 8, 9, 2, 13], dtype=torch.float32)
    n = 741
    dim = 1
    norm = "forward"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
