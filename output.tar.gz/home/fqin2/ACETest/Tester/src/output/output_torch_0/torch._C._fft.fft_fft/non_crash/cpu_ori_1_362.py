import torch
import numpy as np
try:
    input = torch.rand([6, 14], dtype=torch.float32)
    n = 741
    dim = 3
    norm = "backward"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
