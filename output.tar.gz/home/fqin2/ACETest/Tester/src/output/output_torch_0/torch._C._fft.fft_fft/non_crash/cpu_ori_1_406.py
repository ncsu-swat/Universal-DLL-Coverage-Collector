import torch
import numpy as np
try:
    input = torch.rand([1, 14, 13, 13, 15761452563843197294, 9], dtype=torch.float32)
    n = 3370003263937424335
    dim = 3565490145591460093
    norm = "ortho"
    res = torch._C._fft.fft_fft(
        input=input,
        n=n,
        dim=dim,
        norm=norm,
    )
except Exception as e:
    exception_str = str(e)
    ends_with_exception = True
